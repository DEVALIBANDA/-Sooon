#!/usr/bin/env bash
sudo ls
cd Tshake
chmod +x tg
chmod +x ts
chmod +x TsAu
./ts
