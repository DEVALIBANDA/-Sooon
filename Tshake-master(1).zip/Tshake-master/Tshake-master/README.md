TshAkE
==============

______________________________________________________________________________________________________________________

Installation
------------

install :

```git clone https://github.com/tshakeabas/Tshake && cd Tshake && chmod +x install.sh && ./install.sh```

______________________________________________________________________________________________________________________

When the installation is completed,

1. He will asks the token
like :
------

![Token](https://e.top4top.net/p_84060nx91.jpg)

**Type the Token and press Enter**

______________________________________________________________________________________________________________________

2. he will asks the sudo ID
like :
------

![sudo](https://d.top4top.net/p_8405q10k1.jpg)

**Type the Sudo ID and press Enter**

______________________________________________________________________________________________________________________


Run bot
========

______________________________________________________________________________________________________________________


```./Tshake/ts```

______________________________________________________________________________________________________________________

License
-------

The MIT License (MIT)

Copyright (TM) 2018 **TshAkE**

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
